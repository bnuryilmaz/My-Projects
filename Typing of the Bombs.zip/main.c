#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <time.h>

struct game_info{
	int score;
	int letter_number;
	int number_counter;
	int start;
	int bomb_y;
	int bomb_x;
	int mistyped;
	int corrected_typed;
	char word[10];
}; // Define all the variables which will be used in the code.

struct game_info game_data;

void reset_params(){  // Set all variables to initial value which is 0 (zero), except letter_number.
	game_data.score = 0;
	game_data.letter_number = 3; // Minimum value of letters is 3.
	game_data.number_counter = 0;
	game_data.start = 0;
	game_data.mistyped = 0;
	game_data.corrected_typed = 0;
	game_data.bomb_y = 0;
}

void gotoxy(short x, short y){  // Place the cursor at a desired location.
	HANDLE hConsoleOutput;
	COORD Cursor_Pos = {x-1, y-1};
	
	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hConsoleOutput, Cursor_Pos);
}

void screen(){  // Prints the plane, bomb and the city.
	game_data.start = game_data.start % 53;
	FILE *file_city, *file_plane, *file_bomb;
    char c, p[9], b[3];
	int i, j, k;
	
	file_city = fopen("city.txt", "r");
	file_plane = fopen("plane.txt", "r");
	file_bomb = fopen("bomb.txt", "r");

	if(file_city == NULL || file_plane == NULL || file_bomb == NULL){  // If there is no such file for city, plane or bomb, prints "There is file opening error!!".
		printf("There is file opening error!!");
		return;	
	}
	
	printf("\t\t\t\t\t Score: %d\n", game_data.score);  // Prints the scoreboard.
	
	for(i=0; i<5; i++){  // Prints the plane.
		for (j=0; j<game_data.start; j++){
			printf(" ");
		}
		fgets(p, 10, file_plane);
		printf("%s", p);
	}
	
	for(i=0; i<= game_data.bomb_y; i++){  // Prints bombs.
		printf("\n");
	}
	for (i=0; i<4; i++){
		for (j=0; j<game_data.bomb_x; j++){
			printf(" ");
		}
		fgets(b, 4, file_bomb);
		printf("%s",b);
	}	
	gotoxy(game_data.bomb_x+3, game_data.bomb_y+6);
	printf("%s",game_data.word);
	
	for (i=0; i<=30-game_data.bomb_y; i++){  // Prints blanks.
		printf("\n");
	}
	
	c = fgetc(file_city);  // Prints the city.
	while (c != EOF){
		printf("%c", c);
		c = fgetc(file_city);
	}

	fclose(file_city);
	fclose(file_plane);	
	fclose(file_bomb);
}

int drop_bomb(){  // Defines how bombs will be dropped.
	game_data.bomb_x = game_data.start % 53;
	while(strlen(game_data.word)){
		system("cls");
		while (_kbhit()){ 
			char c = _getch();
			if (c == 27){
				display_menu(1);
				return;
			}
			else if (c == game_data.word[0]){  // If the input is equal to first letter of the codeword, correct type counter increases 1.
				game_data.corrected_typed += 1;
				memmove(game_data.word, game_data.word+1, strlen(game_data.word));
			}
			else{  // If the input is not equal to first letter of the codeword, mistype counter increases 1.
				game_data.mistyped += 1;
			}
		}
		game_data.bomb_y++;  // Moves bomb vertically.
		screen(game_data.word);
		int speed = 999999 - (300000*(game_data.letter_number-3));  // Defines the speed of bombs.
		usleep(speed);
		game_data.start++;
		if(game_data.bomb_y==30){  // If the bomb reaches the city, ends the game.
			return 0;
			break;
		}
	}
	game_data.score += game_data.corrected_typed - game_data.mistyped;  // Defines the score.
	game_data.mistyped = 0;  // Sets mistyped counter to 0 (zero) after every bomb.
	game_data.corrected_typed = 0;  // Sets correct type counter to 0 (zero) after every bomb.
	game_data.bomb_y = 0;  // Sets the vertical location of the bomb to 0 (zero) after every bomb.
	return game_data.start;
}

void play(){
	int row_of_word, pointer_position;
	FILE *file_words = fopen("codewords.txt","r");  // Opens codewords file.
	
	if(file_words==NULL){  // If there is no such file, prints "File openning error!".
		printf("File openning error!");
	}
	while(1){
		game_data.number_counter++;
		if(strlen(game_data.word)==0){ //Check if there is a word in memory.
			srand(time(NULL));
			row_of_word = rand() % 5 + 5*(game_data.letter_number-3);
			rewind(file_words);
			for(pointer_position=0;pointer_position<=row_of_word;pointer_position++){
				fscanf(file_words, "%s", game_data.word);
			}	
		}
		game_data.start = drop_bomb();
		if(!game_data.start){
			system("cls");  // If the bomb is not deactivated and touches the city, prints "GAME OVER. Your score is: %d".
			printf("\nGAME OVER. Your score is: %d\n", game_data.score);
			printf("Dou you want to start a new game? (y/n): ");
			char c;
			getchar();
			scanf("%c", &c);
			switch(c){
				case 'y':  // Starts a new game.
					reset_params();
					play();
					break;
				case 'n':  // Exits the program.
					exit(0);
					break;
				default:  // If the input is any differet than "y" or "n", printa "You was entered a non valid character. You moved to main menu.".
					printf("\nYou was entered a non valid character. You moved to main menu.");
					display_menu(0);
			}
			break;
		}
		if(game_data.number_counter % 5 == 0 && game_data.letter_number!= 10){  // Increases letter number up to 10 after every 5 words.
			game_data.letter_number += 1;
		}
	}
}

void load_game(){  // This part defines how a saved game will be loaded.
	char file_name[20];
	FILE *file_load;
	struct game_info game_load;
	
	printf("\nPlease enter file name: ");
	scanf("%s", &file_name);  // Asks user to type a file name.
	
	file_load = fopen(file_name, "rb");
	if(file_load == NULL){  // If there is not such file, prints "There is no such file named %s. Please check the file name!".
		printf("\nThere is no such file named %s. Please check the file name!", file_name);
		display_menu(1);
		return;
	}
	
	fread(&game_load, sizeof(struct game_info), 1, file_load);
	fclose(file_load);
	
	game_data = game_load;
}

void save_game(){  // This part defines how a game will be saved.
	char file_name[20];
	FILE *file_save;
	struct game_info game_save;

	game_save = game_data;

	printf("\nPlease enter a file name: ");
	scanf("%s", &file_name);
	
	file_save = fopen(file_name, "wb");
	if(file_name == NULL){
		printf("There is a problem!");
	}
	fwrite(&game_save, sizeof(struct game_info), 1, file_save);
	fclose(file_save);
	printf("\nYour file has been saved succesfully! %s",game_save.word);
	display_menu(0);
}

void display_menu(int in_game){  // Defines the game menu.
	printf("\n1. New Game");
	printf("\n2. Load a Saved Game");
	if(in_game){  //If the game has already began, there is 5 choice.
		printf("\n3. Save Current Game");
		printf("\n4. Return to Game");
		printf("\n5. Exit");
	
		printf("\nYour choice: ");
		int choice;
		scanf("%d", &choice);
		switch(choice){  // Depend on users choise:
			case 1:  // Resets sthe parameters and the score to 0 (zero) and starts the game.
				game_data.score = 0;
				reset_params();
				play();
				break;
			case 2:  // Loads the saved game and resumes it.
				load_game();
				play();
				break;
			case 3:  // Saves the game.
				save_game();
				break;
			case 4:  // Starts the game without saving or loading any past games.
				play();
				break;
			case 5:  // Exits the program.
				exit(0);
				break;
			default:  // If the input is any different than 1, 2, 3, 4 or 5, prints "Please enter a valid choise".
				printf("Please enter a valid choice");
		}
	}
	else{ // When the program is opened for the first time, there is 3 choise.
		printf("\n3. Exit");
	
		printf("\nYour choice: ");
		int choice;
		scanf("%d", &choice);	
		switch(choice){ // Depend on users choise:
			case 1:  //Resets the parameters to its initial value and starts the game.
				reset_params();
				play();
				break;
			case 2:  // Loads a saved game.
				load_game();
				play();
				break;
			case 3:  // Exits the program.
				exit(0);
				break;
		}
	}
}

int main(){  // Runs the program.
	reset_params();
	display_menu(0);
	return 0;
}
